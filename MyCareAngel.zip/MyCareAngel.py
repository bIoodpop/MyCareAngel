import os
import pygame

pygame.init()

# SCREEN
infoObject = pygame.display.Info()
screen_width, screen_height = infoObject.current_w, infoObject.current_h

# WINDOW 
window_width, window_height = 600, 650
pos_x = (screen_width - window_width) // 2
pos_y = (screen_height - window_height) // 2
os.environ['SDL_VIDEO_WINDOW_POS'] = f"{pos_x},{pos_y}"

#display
win = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("My Care Angel")
font = pygame.font.SysFont(None, 28)

option, option2, option3 = "Fedya", "Kolyunchik", "Sigmochka"
button_x, button_y = 41, 43
button_w, button_h = 215, 50

images = {}
try:
    images["Fedya"] = pygame.image.load('calmFedya.png')
    images["Kolyunchik"] = pygame.image.load('happy kolyunchik.png')
    images["Sigmochka"] = pygame.image.load('happy Sigmochka.png')
    images["confused Sigmochka"] = pygame.image.load('confused Sigmochka.png')
    images["Kolyunchik disappointed"] = pygame.image.load('disappointed Kolya.png')
    images["disappointed Sigmochka"] = pygame.image.load('disappointed Sig.png')
    images["mad Fedya"] = pygame.image.load('mad Fedya.png')
    images["crying Kolyunchik"] = pygame.image.load('crying Kolya.png')
    images["Fedya info"] = pygame.image.load('Fedya info.png')
    images["Kolyunchik info"] = pygame.image.load('Kolyunchik info.png')
    images["Sigmochka info"] = pygame.image.load('Sigmochka info.png')
    for key in images:
        images[key] = pygame.transform.scale(images[key], (500, 500))
except pygame.error as e:
    print("Error loading images:", e)

characters = {
    "Fedya": {"hunger": 50, "hunger_rate": 0.0005, "color": (255, 0, 0), "boredom": 50, "boredom_rate": 0.0005},
    "Kolyunchik": {"hunger": 50, "hunger_rate": 0.002, "color": (0, 255, 0), "boredom": 50, "boredom_rate": 0.005},
    "Sigmochka": {"hunger": 40, "hunger_rate": 0.0003, "color": (0, 0, 255), "boredom": 50, "boredom_rate": 0.0003}
}
Chosen = "Fedya"
menu = False
show_boredom_menu = False
show_food_menu = False
show_angel_info = False
selected_angel = False
selected_item = None
selected_food = None
selected_info = None

clock = pygame.time.Clock()
run = True

food_options = [
    {"name": "Borscht", "color": (255, 58, 36), "effect": +30},
    {"name": "Cookies", "color": (225, 168, 119), "effect": +5},
    {"name": "Piroshki", "color": (255, 218, 185), "effect": +40},
    {"name": "Candy", "color": (255, 54, 209), "effect": +30},
    {"name": "Syrniki", "color": (198, 154, 116), "effect": +30},
]

entertainment_options = [
    {"name": "Cards", "color": (219, 241, 255), "effect": +15},
    {"name": "Music", "color": (126, 77, 210), "effect": +40},
    {"name": "Books", "color": (173, 253, 167), "effect": +15},
    {"name": "Rubix Cube", "color": (245, 255, 151), "effect": +45},
]

angelinfo_options = [
    {"name": "Fedya", "color": (147, 101, 255)},
    {"name": "Kolyunchik", "color": (195, 255, 198)},
    {"name": "Sigmochka", "color": (255, 192, 247)},
]

while run:
    dt = clock.tick(60)  
    mx, my = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if selected_info:
                selected_info = None
            #character menu
            elif button_x < mx < button_x + button_w and button_y < my < button_y + button_h:
                menu = not menu
            elif menu:
                if 50 < mx < 250:
                    if 100 < my < 130:
                        Chosen = "Fedya"
                        menu = False
                    elif 140 < my < 170:
                        Chosen = "Kolyunchik"
                        menu = False
                    elif 180 < my < 210:
                        Chosen = "Sigmochka"
                        menu = False
            #Food selection
            if show_food_menu:
                for i, food in enumerate(food_options):
                    if 470 < mx < 570 and 50 + i * 30 < my < 75 + i * 30:
                        characters[Chosen]["hunger"] += food["effect"]
                        characters[Chosen]["hunger"] = max(0, min(100, characters[Chosen]["hunger"]))
                        show_food_menu = False
            #entertainment options
            if show_boredom_menu:
                for i, entertainment in enumerate(entertainment_options):
                    if 460 < mx < 560 and 50 + i * 30 < my < 75 + i * 30:
                        characters[Chosen]["boredom"] += entertainment["effect"]
                        characters[Chosen]["boredom"] = max(0, min(100, characters[Chosen]["boredom"]))
                        show_boredom_menu = False
            #angel info selection
            if show_angel_info:
                for i, info in enumerate(angelinfo_options):
                    if 480 < mx < 580 and 50 + i * 30 < my < 75 + i * 30:
                        selected_info = info
                        show_angel_info = False

    characters[Chosen]["hunger"] -= characters[Chosen]["hunger_rate"] * dt
    characters[Chosen]["hunger"] = max(0, min(100, characters[Chosen]["hunger"]))

    characters[Chosen]["boredom"] -= characters[Chosen]["boredom_rate"] * dt
    characters[Chosen]["boredom"] = max(0, min(100, characters[Chosen]["boredom"]))

    win.fill((255, 255, 255))

    sprite = images.get(Chosen)
    hunger = int(characters[Chosen]["hunger"])
    boredom = int(characters[Chosen]["boredom"])

    if selected_info:
        info_sprite = images.get(f"{selected_info['name']} info")
        if info_sprite:
            win.blit(info_sprite, (50, 50))
    else:
        if Chosen == "Kolyunchik":
            if hunger < 20:
                sprite = images.get("crying Kolyunchik") or sprite
            elif boredom < 30:
                sprite = images.get("Kolyunchik disappointed") or sprite
            else:
                sprite = images.get("Kolyunchik") or sprite
        elif Chosen == "Sigmochka":
            if hunger < 20:
                sprite = images.get("disappointed Sigmochka") or sprite
            elif boredom < 30:
                sprite = images.get("confused Sigmochka") or sprite
            else:
                sprite = images.get("Sigmochka") or sprite
        elif Chosen == "Fedya":
            if hunger < 30:
                sprite = images.get("mad Fedya") or sprite
            else:
                sprite = images.get("Fedya") or sprite

        if sprite:
            win.blit(sprite, (50, 50))

    pygame.draw.rect(win, (0, 0, 0), (50, 555, 200, 20), 2)  
    pygame.draw.rect(win, (255, 0, 0), (52, 557, (hunger / 100) * 196, 16))
    hunger_text = font.render(f"Hunger: {hunger}", True, (255, 255, 255))
    win.blit(hunger_text, (50, 270))
    hunger_label = font.render("Hunger", True, (0, 0, 0))
    win.blit(hunger_label, (50, 580)) 

    pygame.draw.rect(win, (0, 0, 0), (50, 500, 200, 20), 2)  
    pygame.draw.rect(win, (0, 255, 0), (52, 502, (boredom / 100) * 196, 16))
    boredom_text = font.render(f"Boredom: {boredom}", True, (255, 255, 255))
    win.blit(boredom_text, (50, 0))
    boredom_label = font.render("Boredom", True, (0, 0, 0))
    win.blit(boredom_label, (50, 525))

    pygame.draw.rect(win, (194, 114, 255), (button_x, button_y, button_w, button_h))
    win.blit(font.render("Choose Your Angel", True, (0, 0, 0)), (button_x + 15, button_y + 15))

    pygame.draw.rect(win, (101, 178, 255), (260, 43, 120, 50))
    win.blit(font.render("Angel Info!", True, (0, 0, 0)), (268, 57))

    pygame.draw.rect(win, (0, 200, 0), (150, 600, 100, 40))
    win.blit(font.render("Feed", True, (0, 0, 0)), (175, 610))

    pygame.draw.rect(win, (255, 165, 0), (350, 600, 100, 40))
    win.blit(font.render("Entertain", True, (0, 0, 0)), (357, 610))

    #selection menus
    if menu:
        oy = 100
        for option_text in [option, option2, option3]:
            pygame.draw.rect(win, (191, 210, 255), (50, oy, 200, 30))
            win.blit(font.render(option_text, True, (0, 0, 0)), (60, oy + 5))
            oy += 40

    if show_boredom_menu:
        for i, entertainment in enumerate(entertainment_options):
            pygame.draw.rect(win, entertainment["color"], (460, 50 + i * 30, 100, 25))
            win.blit(font.render(entertainment["name"], True, (0, 0, 0)), (470, 50 + i * 30))
    if selected_item:
        win.blit(font.render(f"Selected: {selected_item['name']}", True, (0, 0, 0)), (250, 650))

    if show_food_menu:
        for i, food in enumerate(food_options):
            pygame.draw.rect(win, food["color"], (470, 50 + i * 30, 100, 25))
            win.blit(font.render(food["name"], True, (0, 0, 0)), (480, 50 + i * 30))
    if selected_food:
        win.blit(font.render(f"Selected: {selected_food['name']}", True, (0, 0, 0)), (250, 650))
    
    if show_angel_info:
        for i, info in enumerate(angelinfo_options):
            pygame.draw.rect(win, info["color"], (480, 50 + i * 30, 100, 25))
            win.blit(font.render(info["name"], True, (0, 0, 0)), (490, 50 + i * 30))
    if selected_info:
        win.blit(font.render(f"Info: {selected_info['name']}", True, (0, 0, 0)), (250, 650))
                     
    if pygame.mouse.get_pressed()[0]:
        if 150 < mx < 250 and 600 < my < 640:
            show_food_menu = not show_food_menu
        if 350 < mx < 450 and 600 < my < 640:
            show_boredom_menu = not show_boredom_menu
        if 250 < mx < 350 and 43 < my < 93:
            show_angel_info = not show_angel_info

    pygame.display.flip()

pygame.quit()